# Physics + Python workshops — teacher notes

Give students only `conversion_workshop.py` and `kinematics_1d_workshop.py`.
Keep the files ending `_solution.py` and this teacher pack for yourself.
The solutions are complete, standalone copies with the same stage selector.

## Before class

1. Use Python 3 and a code editor; students need functions, return, lists and loops.
2. Install the only direct third-party dependency in the terminal:
   `python -m pip install matplotlib`.
   Use `py` on Windows or `python3` on macOS/Linux if needed, consistently for
   both installation and execution. Do not name a file `matplotlib.py`.
3. Open each student file and run with `STAGE = 0`. This stage already works.
4. Check that a graph window or a PNG appears. Each plot is saved beside the
   script; rerunning the same stage replaces that stage's PNG. Rename any
   image students want to retain before another run. On a computer without a
   graphical display, set `SHOW_PLOTS = False` and view the PNG separately.
5. Print Physics Period1 Exer1 and Exer3. Exer3 is labelled Week 3 in the
   original course: we are selecting its 1D questions for your first class.

Matplotlib setup and supplied subplot code follow the official documentation:
[installation](https://matplotlib.org/stable/install/index.html) and
[subplots](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.subplots.html).
No Manim, animation renderer, classes or direct NumPy programming are needed.

## Delivery pattern

Ask students to **predict on paper, code, run, then explain**. Change the STAGE
number only when the group is ready. Students edit the labelled TODO/BUG
functions; the supplied plotting section is not a coding task. The files are
long because the instructions, test harness and plots are self-contained.

`TODO` means a function is unfinished; `CHECK` means a numerical result differs
from the expected result. Neither necessarily indicates a Python syntax error.
Some wrong implementations deliberately still produce graphs: make students
compare them with the independent paper checkpoints. A plot is not proof.
The checks cover representative cases, not every possible incorrect program.
Students should preserve tests and generalise functions, not hard-code answers.

Suggested pair roles: one student predicts and explains the units, the other
edits and runs; swap every stage. Require each student to write their own paper
solution. An optional assessment split is physics reasoning 40%, correct code
30%, plot interpretation 20%, tests and clear names 10% (not an official rubric).

## Workshop 1: conversion (50 minutes including optional stage 3)

| Stage | Time | Student work | Paper connection |
|---|---:|---|---|
| 0 | 5 min | Run km-to-m demo; explain graph slope | Cancelling units |
| 1 | 15 min | Fix km/h bug; implement reverse and mi/h conversion | Exer1 Q8 and Q5 |
| 2 | 15 min | Convert via base units using prefix dictionary | Exer1 Q1 and Q2 |
| 3 | 10 min | Repair squared/cubed conversion factor | Exer1 Q6 |
| Close | 5 min | Exit ticket and independent explanation | One handwritten conversion |

Solutions to edit points:

- A: `speed_kmh / 3.6`
- B: `speed_ms * 3.6`
- C: `speed_mph * 1609.344 / 3600`
- D: `base_value = value * PREFIX[from_prefix]`, followed by
  `converted_value = base_value / PREFIX[to_prefix]`
- E: `value * 100 ** dimension`

Answer checks: 36 km/h = 10 m/s; 1 m/s = 3.6 km/h; 35 mi/h = 15.6464 m/s
(approximately 51.3333 ft/s); 1000 MW = 1e9 W = 1e6 kW = 1 GW.
The diameter ratio in Exer1 Q2 is 100000. One cubic metre is 1000000 cm³.
One square metre is 10000 cm². These factors apply to the whole unit.

Graph interpretations: the stage 0 slope is 1000 m per km; the stage 1 slope is
1/3.6 (m/s) per (km/h). These are conversion graphs, NOT time graphs: their
slopes are not velocity or acceleration. The prefix plot shows the SAME power
with different numerical representations. Log-axis equal intervals are equal
multiplicative factors. The final graph compares conversion factors, not the
physical magnitudes of length, area and volume.

Round-trip tests alone are insufficient: two wrong functions can undo each
other. Also use independently hand-calculated values. Floating-point checks use
`isclose`; keep full precision internally and round only displayed answers.

## Workshop 2: 1D kinematics (60 minutes + optional 15 minutes)

| Stage | Time | Student work | Physics focus |
|---|---:|---|---|
| 0 | 5 min | Read a working position function | Position vs displacement |
| 1 | 15 min | Implement velocity equation | Acceleration as velocity slope |
| 2 | 20 min | Fix missing time square; vary acceleration | Three related graphs |
| 3 | 20 min | Calculate stopping acceleration, then Exer3 Q5 | SI conversion and braking |
| 4 | Optional 15 min | Find fall time; use upward-positive coordinates | Exer3 Q3 and free fall |

Solutions to edit points:

- A: `v0 + a * t`
- B: `x0 + v0 * t + 0.5 * a * t ** 2`
- C: `(0 - v0) / stopping_time`
- D: `sqrt(2 * height / g)`

Default answers:

- Stage 0: final position 14 m; displacement 12 m.
- Stage 1: velocity table at 0, 1, 2, 3 s is 2, 3, 4, 5 m/s.
- Stage 2: at 4 s, x = 16 m, v = 6 m/s, a = 1 m/s². Position is curved;
  velocity is a rising straight line; acceleration is horizontal. The velocity
  graph's trapezium area is (2 + 6)/2 × 4 = 16 m.
- Stage 2 with a = -1: the cart reverses at 2 s and x = 2 m; at 4 s it returns
  to x = 0. Total distance is 4 m but displacement is 0. Before the turn it
  slows down; after the turn it speeds up leftward. At the turn v = 0 but
  a = -1 m/s². This is not a parked-cart model.
- Stage 3 toy cart: a = -2 m/s²; final velocity 0; displacement 9 m. The triangle
  under velocity-time has area (1/2) × 3 × 6 = 9 m.
- Exer3 Q5: v0 = 220/3.6 = 61.1111... m/s; a = -2.10728... m/s²;
  stopping displacement = 886.111... m (about 886 m). After solving on paper,
  students can change the two stage 3 settings to plot this scenario.
- Stage 4: from 20 m, impact time ≈ 2.01928 s; impact velocity ≈ -19.8091 m/s;
  speed ≈ 19.8091 m/s. Final height is zero within floating-point error.
- Exer3 Q3: distance = 0.5 × 9.81 × 4.4² = 94.9608 m, about 95 m. Under the
  question's simplifying assumption, treat 4.4 s as fall time; ignore sound.

Teacher prompts: “What are the units?” “Which direction did you choose as
positive?” “Does the graph agree with your table?” “Are you reading the graph's
height or its slope?” The signed area under velocity-time is displacement;
total distance counts areas below zero positively. Constant acceleration is
essential to the equations and the trapezium-area calculation used here.

The scripts stop the braking scenario at rest and free fall at ground contact.
They do not model reaction time, changing braking force, drag or bouncing.
Small negative residual heights around 1e-15 m are floating-point rounding.

## Timing if using both in one class

The full sequence takes roughly two hours plus transitions, beyond a short
add-on. For a 30–40 minute CS integration slot, run conversion stages 0–1 and
kinematics stages 0–2 selectively, demonstrating the supplied plotting code.
Set the remaining stages as follow-up work; do not rush the paper predictions.

## Included reference plots and verification

The teacher pack includes PNGs from every completed solution stage. They are
fallbacks if classroom plotting fails; do not distribute them before students
make predictions. Both untouched starter files and every completed solution
stage were run in a non-interactive plotting environment. Untouched starters
intentionally report TODO/CHECK at unfinished stages. Complete solutions pass
the numerical checks, including signed-area consistency. Interactive windows
still depend on the classroom computer's graphics setup.
